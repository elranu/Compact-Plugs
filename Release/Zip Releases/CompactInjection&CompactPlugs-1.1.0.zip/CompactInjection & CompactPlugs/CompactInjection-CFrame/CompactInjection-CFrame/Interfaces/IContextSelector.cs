//Develop by Mariano Julio Vicario -
//http://compactplugs.codeplex.com/
//http://www.ranu.com.ar (Blog)
//Microsoft Public License (Ms-PL)
using System;
using System.Collections.Generic;
using System.Text;

namespace CompactInjection.Interfaces
{
    public interface IContextSelector
    {
        string GetCurrentContext();
    
    }
}
