using System;
using System.Collections.Generic;
using System.Text;

namespace TestInjection
{
    public class Object2
    {
        private int _Inte;

        public int Inte2
        {
            get { return _Inte; }
            set { _Inte = value; }
        }
	
    
    }
}
